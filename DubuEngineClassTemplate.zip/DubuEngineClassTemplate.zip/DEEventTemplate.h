#pragma once
#include "DEEvents.h"

class $safeitemname$
{
public:
	$safeitemname$();
	~$safeitemname$();
};

int Register$safeitemname$Events(TimerEventFunction* t, MouseEventFunction* c, KeyboardEventFunction* p);
